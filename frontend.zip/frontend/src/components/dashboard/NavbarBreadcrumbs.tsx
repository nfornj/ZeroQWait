import { styled } from '@mui/material/styles';
import Typography from '@mui/material/Typography';
import Breadcrumbs, { breadcrumbsClasses } from '@mui/material/Breadcrumbs';
import NavigateNextRoundedIcon from '@mui/icons-material/NavigateNextRounded';

const StyledBreadcrumbs = styled(Breadcrumbs)(({ theme }) => ({
  margin: theme.spacing(1, 0),
  [`& .${breadcrumbsClasses.separator}`]: {
    color: (theme.vars || theme).palette.action.disabled,
    margin: 1,
  },
  [`& .${breadcrumbsClasses.ol}`]: {
    alignItems: 'center',
  },
}));

import { useLocation } from 'react-router-dom';

const routeNameMap: { [key: string]: string } = {
  '/dashboard': 'Home',
  '/queues': 'Queues',
  '/employees': 'Team',
  '/analytics': 'Analytics',
  '/settings': 'Settings',
};

export default function NavbarBreadcrumbs() {
  const location = useLocation();
  const currentPath = location.pathname;
  const pageName = routeNameMap[currentPath] || 'Overview';

  return (
    <StyledBreadcrumbs
      aria-label="breadcrumb"
      separator={<NavigateNextRoundedIcon fontSize="small" />}
    >
      <Typography variant="body1">Dashboard</Typography>
      <Typography variant="body1" sx={{ color: 'text.primary', fontWeight: 600 }}>
        {pageName}
      </Typography>
    </StyledBreadcrumbs>
  );
}
