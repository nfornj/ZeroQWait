import { IconButtonOwnProps } from '@mui/material/IconButton';

export default function ColorModeIconDropdown(props: IconButtonOwnProps) {
  // Temporary disable for v5 compatibility
  return null;
}
